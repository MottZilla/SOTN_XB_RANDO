This program will simply extract the files from your SotN LIVE container file so you can use the randomizer.
Put LIVE_Extract.exe and decrypt.xor into a folder with your SotN LIVE container file.
Then drag and drop the LIVE container file with the name 9F2DAA064D494AA82B43B65362C59E9B89A88F8F58
onto the LIVE_Extract program. It will extract all the files.

Source code is included for anyone that wants to look or build themselves.

If the file *decrypt.xor* is not present then you'll need to decrypt the XEX with XexTool.
